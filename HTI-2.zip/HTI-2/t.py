def main():
    print(2)
    
    

main()