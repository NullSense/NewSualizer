<?php

	//$command = escapeshellcmd('public_html/HTI/t.py');
	//$output = shell_exec($command);
	//echo $output;
	
	$output=shell_exec('python ./HDTrees.py ./test.txt');
	echo $output;


?>